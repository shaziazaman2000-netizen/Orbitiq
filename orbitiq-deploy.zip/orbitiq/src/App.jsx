import { useState, useRef, useEffect } from "react";

const TOOLS = [
  { id: "coach", name: "Life Coach", tagline: "AI that transforms your mindset", icon: "🧠", color: "#e879f9", glow: "rgba(232,121,249,0.4)",
    prompt: (q) => `You are an elite life coach with 20 years experience. The user says: "${q}". Give a powerful, personalized coaching response with: 1) A direct insight about their situation, 2) The core mindset shift they need, 3) Three concrete action steps they can take THIS WEEK. Be bold, direct, and transformative. No generic advice.`,
    placeholder: "What challenge are you facing in life right now?",
    examples: ["I feel stuck in my career", "I struggle with self-confidence", "How do I stop procrastinating?"] },
  { id: "viral", name: "Viral Creator", tagline: "Content that breaks the internet", icon: "⚡", color: "#fb923c", glow: "rgba(251,146,60,0.4)",
    prompt: (q) => `You are a viral content strategist who has grown accounts to millions of followers. Topic: "${q}". Generate: 1) 3 scroll-stopping hook lines, 2) A viral Twitter/X thread (5 tweets), 3) An Instagram caption with hashtags, 4) A 30-second video script opening. Make it emotional, controversial, or shocking enough to share.`,
    placeholder: "Enter your topic, niche, or product...",
    examples: ["Morning routines that changed my life", "Why 9-to-5 jobs are dying", "I tried AI tools for 30 days"] },
  { id: "business", name: "Biz Validator", tagline: "Know if your idea will print money", icon: "💼", color: "#34d399", glow: "rgba(52,211,153,0.4)",
    prompt: (q) => `You are a serial entrepreneur and venture capitalist. Business idea: "${q}". Analyze with: 1) Viability Score (1-10) with reasoning, 2) Market size estimate, 3) Top 3 competitors and gaps, 4) Revenue model options, 5) Biggest risk, 6) One unique angle nobody is doing. Give a VERDICT: GO / PIVOT / KILL with one-line reason.`,
    placeholder: "Describe your business idea...",
    examples: ["AI-powered meal planning app", "Subscription box for plant parents", "Online school for freelancers"] },
  { id: "resume", name: "Bio Writer", tagline: "Words that open every door", icon: "🎯", color: "#60a5fa", glow: "rgba(96,165,250,0.4)",
    prompt: (q) => `You are an elite copywriter and personal branding expert. User info: "${q}". Create: 1) A powerful 3-sentence professional bio for LinkedIn, 2) A punchy Twitter/X bio (160 chars), 3) A compelling cover letter opening paragraph, 4) Three powerful bullet points summarizing their value. Make them sound exceptional, credible, and magnetic.`,
    placeholder: "Tell me about yourself - job, skills, goals...",
    examples: ["Software engineer, 3 years experience, want to switch to AI", "Marketing student, content creator, 10k followers", "Teacher wanting to become online course creator"] },
  { id: "dream", name: "Dream Oracle", tagline: "Unlock your subconscious mind", icon: "🔮", color: "#a78bfa", glow: "rgba(167,139,250,0.4)",
    prompt: (q) => `You are a Jungian psychologist and dream analyst. Dream: "${q}". Provide: 1) Primary psychological interpretation, 2) Key symbols and their meaning, 3) What your subconscious is trying to tell you, 4) An emotional or life message hidden in this dream, 5) One actionable reflection question. Be insightful, poetic, and psychologically grounded.`,
    placeholder: "Describe your dream in detail...",
    examples: ["I was flying over a city then fell", "I was being chased through a forest", "I was back in school and forgot an exam"] },
  { id: "solver", name: "Problem Solver", tagline: "Every problem has an elite solution", icon: "💡", color: "#fbbf24", glow: "rgba(251,191,36,0.4)",
    prompt: (q) => `You are a world-class strategist combining first-principles thinking and creative problem-solving. Problem: "${q}". Deliver: 1) Root cause analysis, 2) Three solution frameworks (conventional / creative / radical), 3) Step-by-step action plan, 4) Potential obstacles and how to overcome them, 5) A mental model to prevent this problem in future.`,
    placeholder: "What problem do you need solved?",
    examples: ["I have no time for anything I care about", "My team won't follow my leadership", "I keep running out of money before payday"] },
  { id: "email", name: "Email Wizard", tagline: "Emails that get replies every time", icon: "✉️", color: "#f472b6", glow: "rgba(244,114,182,0.4)",
    prompt: (q) => `You are a world-class email copywriter. Request: "${q}". Write: 1) A subject line with 60%+ open rate, 2) The full email (professional yet human), 3) A follow-up version if no reply in 3 days, 4) One-line cold DM version for LinkedIn/Instagram. Make it persuasive, clear, and impossible to ignore.`,
    placeholder: "Who are you emailing and what is the goal?",
    examples: ["Cold email to a CEO for a job", "Ask a client for a testimonial", "Pitch my freelance services to a startup"] },
  { id: "chef", name: "Chef AI", tagline: "Restaurant-quality meals from anything", icon: "🍳", color: "#4ade80", glow: "rgba(74,222,128,0.4)",
    prompt: (q) => `You are a Michelin-star chef and nutritionist. Input: "${q}". Provide: 1) A creative recipe name, 2) Full ingredients list with quantities, 3) Step-by-step cooking instructions, 4) Nutrition highlights (calories, protein etc.), 5) A pro chef tip to elevate the dish, 6) One easy substitution for dietary restrictions.`,
    placeholder: "What ingredients do you have, or what do you want to eat?",
    examples: ["Chicken, rice, and whatever is in my fridge", "A healthy high-protein breakfast", "Impress a date with a 3-course dinner"] },
  { id: "study", name: "Study Genius", tagline: "Learn anything 10x faster", icon: "📚", color: "#38bdf8", glow: "rgba(56,189,248,0.4)",
    prompt: (q) => `You are an expert educator using neuroscience-backed learning techniques. Topic: "${q}". Create: 1) A 5-minute crash course summary, 2) The 3 most important concepts to master first, 3) A memory trick or mnemonic to remember key facts, 4) 5 practice questions with answers, 5) Recommended next steps to go deeper.`,
    placeholder: "What do you want to learn or understand?",
    examples: ["Explain quantum physics simply", "How does the stock market work", "Help me understand machine learning"] },
  { id: "fitness", name: "Fit Planner", tagline: "Your personal AI trainer and dietitian", icon: "💪", color: "#f87171", glow: "rgba(248,113,113,0.4)",
    prompt: (q) => `You are an elite personal trainer and certified nutritionist. Request: "${q}". Provide: 1) A custom weekly workout plan (with sets/reps), 2) Daily meal plan with macros, 3) One supplement recommendation (safe and evidence-based), 4) A mindset tip for staying consistent, 5) A 30-day progress milestone to aim for.`,
    placeholder: "Your goal, fitness level, and any equipment you have...",
    examples: ["Lose 10kg, beginner, no gym", "Build muscle, intermediate, home dumbbells", "Improve running endurance for 5K"] },
];

export default function App() {
  const [screen, setScreen] = useState("landing");
  const [activeTool, setActiveTool] = useState(null);
  const [input, setInput] = useState("");
  const [response, setResponse] = useState("");
  const [loading, setLoading] = useState(false);
  const [history, setHistory] = useState([]);
  const [particles, setParticles] = useState([]);
  const [typed, setTyped] = useState("");
  const [showHistory, setShowHistory] = useState(false);
  const [darkMode, setDarkMode] = useState(true);
  const [copied, setCopied] = useState(false);
  const [pdfLoading, setPdfLoading] = useState(false);
  const outputRef = useRef(null);

  const D = darkMode ? {
    bg: "#030508", bg2: "rgba(255,255,255,0.02)", bg3: "rgba(255,255,255,0.05)",
    border: "rgba(255,255,255,0.08)", text: "#e5e7eb", textMuted: "#6b7280",
    textFaint: "#374151", card: "rgba(255,255,255,0.025)", navBg: "rgba(3,5,8,0.97)",
    inputBg: "rgba(0,0,0,0.2)", scrollThumb: "#333",
  } : {
    bg: "#f5f4f0", bg2: "rgba(0,0,0,0.03)", bg3: "rgba(0,0,0,0.06)",
    border: "rgba(0,0,0,0.1)", text: "#1a1a2e", textMuted: "#555",
    textFaint: "#999", card: "rgba(255,255,255,0.85)", navBg: "rgba(245,244,240,0.97)",
    inputBg: "rgba(255,255,255,0.95)", scrollThumb: "#ccc",
  };

  useEffect(() => {
    const p = Array.from({ length: 25 }, (_, i) => ({
      id: i, x: Math.random() * 100, y: Math.random() * 100,
      size: Math.random() * 3 + 1, speed: Math.random() * 20 + 10,
      opacity: Math.random() * 0.3 + 0.05,
      color: TOOLS[Math.floor(Math.random() * TOOLS.length)].color,
    }));
    setParticles(p);
  }, []);

  const tagline = "INTELLIGENCE THAT ORBITS AROUND YOU";
  useEffect(() => {
    if (screen !== "home") return;
    let i = 0; setTyped("");
    const t = setInterval(() => { setTyped(tagline.slice(0, i)); i++; if (i > tagline.length) clearInterval(t); }, 55);
    return () => clearInterval(t);
  }, [screen]);

  const runTool = async (tool, overrideInput) => {
    const q = (overrideInput || input).trim();
    if (!q) return;
    setLoading(true); setResponse("");
    try {
      const res = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: "claude-sonnet-4-20250514", max_tokens: 1000,
          messages: [{ role: "user", content: tool.prompt(q) }],
        }),
      });
      const data = await res.json();
      const text = data.content?.[0]?.text || "No response generated.";
      setResponse(text);
      setHistory(prev => [{ tool: tool.name, icon: tool.icon, input: q, output: text, color: tool.color, time: new Date().toLocaleTimeString() }, ...prev.slice(0, 9)]);
    } catch { setResponse("Connection error. Please try again."); }
    setLoading(false);
  };

  const copyResponse = () => {
    navigator.clipboard?.writeText(response);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const exportPDF = () => {
    if (!response || !activeTool) return;
    setPdfLoading(true);
    const t = TOOLS.find(x => x.id === activeTool);
    const win = window.open("", "_blank");
    if (!win) { setPdfLoading(false); return; }
    win.document.write(`<!DOCTYPE html><html><head><title>ORBITIQ - ${t.name}</title>
    <style>
      body { font-family: Georgia, serif; background: #030508; color: #e5e7eb; padding: 60px; max-width: 780px; margin: 0 auto; }
      h1 { font-size: 28px; letter-spacing: 6px; color: ${t.color}; margin-bottom: 4px; text-transform: uppercase; }
      .sub { font-size: 9px; letter-spacing: 4px; color: #4a5568; margin-bottom: 36px; }
      .label { font-size: 9px; letter-spacing: 3px; color: ${t.color}; margin-bottom: 8px; text-transform: uppercase; }
      .query { background: rgba(255,255,255,0.04); border: 1px solid ${t.color}44; border-radius: 10px; padding: 14px 18px; margin-bottom: 24px; font-style: italic; color: #9ca3af; font-size: 14px; }
      .divider { border: none; border-top: 1px solid rgba(255,255,255,0.07); margin: 20px 0; }
      .response { line-height: 1.9; font-size: 14px; white-space: pre-wrap; color: #d1d5db; }
      strong { color: ${t.color}; }
      .footer { font-size: 9px; letter-spacing: 3px; color: #374151; margin-top: 50px; text-transform: uppercase; }
    </style></head><body>
      <h1>${t.icon} ${t.name}</h1>
      <div class="sub">ORBITIQ ORBITAL INTELLIGENCE SUITE &middot; ${new Date().toLocaleDateString()}</div>
      <div class="label">Your Query</div>
      <div class="query">${input}</div>
      <div class="label">&#10022; ORBITIQ Response</div>
      <hr class="divider"/>
      <div class="response">${response.replace(/\*\*(.*?)\*\*/g, "<strong>$1</strong>")}</div>
      <hr class="divider"/>
      <div class="footer">Generated by ORBITIQ AI &middot; Powered by Claude &middot; orbitiq.ai</div>
    </body></html>`);
    win.document.close();
    setTimeout(() => { win.print(); setPdfLoading(false); }, 600);
  };

  const tool = activeTool ? TOOLS.find(t => t.id === activeTool) : null;

  const css = `
    @import url('https://fonts.googleapis.com/css2?family=Cinzel:wght@400;600;900&family=Crimson+Pro:ital,wght@0,300;0,400;1,300&display=swap');
    * { box-sizing: border-box; margin: 0; padding: 0; }
    ::-webkit-scrollbar { width: 4px; }
    ::-webkit-scrollbar-track { background: transparent; }
    ::-webkit-scrollbar-thumb { background: ${D.scrollThumb}; border-radius: 4px; }
    textarea, input { outline: none; }
    @keyframes float { 0%,100%{transform:translateY(0)} 50%{transform:translateY(-18px)} }
    @keyframes pulse-glow { 0%,100%{opacity:0.5} 50%{opacity:1} }
    @keyframes spin-slow { from{transform:rotate(0deg)} to{transform:rotate(360deg)} }
    @keyframes shimmer { 0%{background-position:-200% 0} 100%{background-position:200% 0} }
    @keyframes fadeUp { from{opacity:0;transform:translateY(22px)} to{opacity:1;transform:translateY(0)} }
    @keyframes scanline { 0%{top:-5%} 100%{top:105%} }
    @keyframes breathe { 0%,100%{transform:scale(1) rotate(0deg)} 50%{transform:scale(1.06) rotate(4deg)} }
    @keyframes gradientShift { 0%{background-position:0% 50%} 50%{background-position:100% 50%} 100%{background-position:0% 50%} }
    .tool-card { transition: transform 0.3s cubic-bezier(0.34,1.56,0.64,1), box-shadow 0.3s; cursor: pointer; }
    .tool-card:hover { transform: translateY(-7px) scale(1.03); }
    .glow-btn { position: relative; overflow: hidden; }
    .glow-btn::before { content:''; position:absolute; inset:0; background:linear-gradient(90deg,transparent,rgba(255,255,255,0.12),transparent); transform:translateX(-100%); transition:transform 0.5s; border-radius:inherit; }
    .glow-btn:hover::before { transform:translateX(100%); }
    .example-chip:hover { opacity:1 !important; transform:translateY(-2px) !important; cursor:pointer; }
    .nav-pill:hover { opacity:1 !important; transform:scale(1.04); }
    .hist-item:hover { background: rgba(255,255,255,0.04) !important; cursor:pointer; }
  `;

  // LANDING
  if (screen === "landing") return (
    <div style={{ minHeight:"100vh", background:"#030508", fontFamily:"Georgia, serif", position:"relative", overflow:"hidden", display:"flex", alignItems:"center", justifyContent:"center" }}>
      <style>{css}</style>
      <div style={{ position:"fixed", inset:0, background:"linear-gradient(135deg,#0d0020,#030508,#001a0d,#030508,#1a0010)", backgroundSize:"400% 400%", animation:"gradientShift 14s ease infinite", zIndex:0 }} />
      {particles.map(p => (
        <div key={p.id} style={{ position:"fixed", left:`${p.x}%`, top:`${p.y}%`, width:p.size, height:p.size, borderRadius:"50%", background:p.color, opacity:p.opacity, animation:`float ${p.speed}s ease-in-out infinite`, animationDelay:`${p.id*0.4}s`, pointerEvents:"none", zIndex:1 }} />
      ))}
      <div style={{ position:"fixed", left:0, right:0, height:2, background:"linear-gradient(90deg,transparent,rgba(255,255,255,0.04),transparent)", animation:"scanline 10s linear infinite", zIndex:2, pointerEvents:"none" }} />

      <div style={{ position:"relative", zIndex:5, maxWidth:680, padding:"40px 28px", textAlign:"center", animation:"fadeUp 0.8s ease" }}>
        <div style={{ fontSize:70, animation:"breathe 5s ease-in-out infinite", marginBottom:22, filter:"drop-shadow(0 0 40px rgba(167,139,250,0.6))" }}>✦</div>
        <div style={{ fontFamily:"'Cinzel', serif", fontSize:"clamp(52px,13vw,92px)", fontWeight:900, letterSpacing:14, background:"linear-gradient(135deg,#e879f9,#a78bfa,#60a5fa,#34d399,#fbbf24)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent", backgroundSize:"300% 300%", animation:"gradientShift 7s ease infinite", lineHeight:1, marginBottom:10 }}>ORBITIQ</div>
        <div style={{ fontFamily:"'Cinzel', serif", fontSize:10, letterSpacing:8, color:"#4a5568", marginBottom:28 }}>ORBITAL INTELLIGENCE SUITE</div>
        <p style={{ fontFamily:"'Crimson Pro', serif", fontSize:18, fontStyle:"italic", color:"#9ca3af", lineHeight:1.9, maxWidth:480, margin:"0 auto 28px" }}>
          Ten AI-powered tools in one orbital platform. Intelligence that revolves around you.
        </p>

        <div style={{ display:"flex", gap:7, flexWrap:"wrap", justifyContent:"center", marginBottom:36 }}>
          {TOOLS.map(t => (
            <div key={t.id} style={{ padding:"5px 12px", borderRadius:20, border:`1px solid ${t.color}33`, color:t.color, fontSize:10, fontFamily:"'Cinzel', serif", letterSpacing:1 }}>
              {t.icon} {t.name}
            </div>
          ))}
        </div>

        <button className="glow-btn" onClick={() => setScreen("home")}
          style={{ background:"linear-gradient(135deg,#e879f9,#a78bfa)", border:"none", borderRadius:14, padding:"18px 56px", color:"#030508", fontFamily:"'Cinzel', serif", fontSize:14, fontWeight:700, letterSpacing:5, cursor:"pointer", boxShadow:"0 0 60px rgba(167,139,250,0.45)", display:"inline-block" }}>
          ENTER ORBIT
        </button>
        <div style={{ fontFamily:"'Cinzel', serif", fontSize:9, letterSpacing:3, color:"#374151", marginTop:18 }}>POWERED BY CLAUDE AI &middot; FREE &middot; NO SIGNUP REQUIRED</div>
      </div>

      <button onClick={() => setDarkMode(!darkMode)} style={{ position:"fixed", top:18, right:18, background:"rgba(255,255,255,0.06)", border:"1px solid rgba(255,255,255,0.1)", borderRadius:30, padding:"7px 16px", color:"#9ca3af", cursor:"pointer", fontSize:11, fontFamily:"'Cinzel', serif", letterSpacing:2, zIndex:10 }}>
        {darkMode ? "☀ LIGHT" : "◑ DARK"}
      </button>
    </div>
  );

  // MAIN APP
  return (
    <div style={{ minHeight:"100vh", background:D.bg, fontFamily:"Georgia, serif", position:"relative", overflow:"hidden", transition:"background 0.4s, color 0.4s" }}>
      <style>{css}</style>

      {particles.slice(0,12).map(p => (
        <div key={p.id} style={{ position:"fixed", left:`${p.x}%`, top:`${p.y}%`, width:p.size*0.7, height:p.size*0.7, borderRadius:"50%", background:p.color, opacity:p.opacity*0.4, animation:`float ${p.speed}s ease-in-out infinite`, animationDelay:`${p.id*0.4}s`, pointerEvents:"none", zIndex:0 }} />
      ))}
      <div style={{ position:"fixed", left:0, right:0, height:1, background:`linear-gradient(90deg,transparent,${darkMode?"rgba(255,255,255,0.03)":"rgba(0,0,0,0.02)"},transparent)`, animation:"scanline 12s linear infinite", zIndex:1, pointerEvents:"none" }} />
      <div style={{ position:"fixed", inset:0, zIndex:0, background: tool ? `radial-gradient(ellipse 70% 50% at 50% 10%, ${tool.glow.replace("0.4","0.07")} 0%, transparent 70%)` : "none", transition:"background 0.8s", pointerEvents:"none" }} />

      {/* HEADER */}
      <div style={{ position:"relative", zIndex:10, padding:"16px 20px 0", display:"flex", alignItems:"center", justifyContent:"space-between" }}>
        <div onClick={() => { setActiveTool(null); setResponse(""); setInput(""); setScreen("home"); }} style={{ cursor:"pointer" }}>
          <div style={{ fontFamily:"'Cinzel', serif", fontSize:19, fontWeight:900, letterSpacing:6, background:"linear-gradient(135deg,#e879f9,#60a5fa,#34d399)", WebkitBackgroundClip:"text", WebkitTextFillColor:"transparent" }}>ORBITIQ</div>
          <div style={{ fontSize:7, letterSpacing:4, color:D.textFaint, fontFamily:"'Cinzel', serif" }}>ORBITAL INTELLIGENCE SUITE</div>
        </div>
        <div style={{ display:"flex", gap:8, alignItems:"center" }}>
          <div style={{ width:7, height:7, borderRadius:"50%", background:"#34d399", boxShadow:"0 0 8px #34d399", animation:"pulse-glow 2s ease-in-out infinite" }} />
          <span style={{ fontSize:8, color:"#34d399", letterSpacing:2, fontFamily:"'Cinzel', serif" }}>LIVE</span>
          <button onClick={() => setDarkMode(!darkMode)} style={{ background:D.bg3, border:`1px solid ${D.border}`, borderRadius:20, padding:"5px 12px", color:D.textMuted, cursor:"pointer", fontSize:10, letterSpacing:1, fontFamily:"'Cinzel', serif", transition:"all 0.3s" }}>
            {darkMode ? "☀" : "◑"}
          </button>
          {history.length > 0 && (
            <button onClick={() => setShowHistory(!showHistory)} style={{ background:D.bg3, border:`1px solid ${D.border}`, borderRadius:6, padding:"5px 10px", color:D.textMuted, cursor:"pointer", fontSize:9, letterSpacing:1, fontFamily:"'Cinzel', serif" }}>
              ⏱ {history.length}
            </button>
          )}
        </div>
      </div>

      {/* HISTORY DRAWER */}
      {showHistory && (
        <div style={{ position:"fixed", top:0, right:0, bottom:0, width:290, background: darkMode ? "rgba(4,5,10,0.98)" : "rgba(248,247,244,0.98)", borderLeft:`1px solid ${D.border}`, zIndex:100, padding:18, overflowY:"auto", animation:"fadeUp 0.2s ease" }}>
          <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:16 }}>
            <span style={{ fontFamily:"'Cinzel', serif", fontSize:10, letterSpacing:3, color:D.textMuted }}>HISTORY</span>
            <button onClick={() => setShowHistory(false)} style={{ background:"none", border:"none", color:D.textMuted, cursor:"pointer", fontSize:20 }}>×</button>
          </div>
          {history.map((h, i) => (
            <div key={i} className="hist-item" onClick={() => { const t = TOOLS.find(x => x.name===h.tool); if(t){setActiveTool(t.id);setInput(h.input);setResponse(h.output);setShowHistory(false);setScreen("tool");} }}
              style={{ background:D.bg2, border:`1px solid ${h.color}22`, borderRadius:10, padding:12, marginBottom:8, transition:"background 0.2s" }}>
              <div style={{ fontSize:9, color:h.color, letterSpacing:2, fontFamily:"'Cinzel', serif" }}>{h.icon} {h.tool}</div>
              <div style={{ fontSize:12, color:D.textMuted, marginTop:4, lineHeight:1.4 }}>{h.input.length>55?h.input.slice(0,55)+"…":h.input}</div>
              <div style={{ fontSize:9, color:D.textFaint, marginTop:4 }}>{h.time}</div>
            </div>
          ))}
        </div>
      )}

      <div style={{ maxWidth:680, margin:"0 auto", padding:"0 20px 60px", position:"relative", zIndex:5 }}>

        {/* HOME */}
        {screen === "home" && (
          <div style={{ animation:"fadeUp 0.5s ease" }}>
            <div style={{ textAlign:"center", padding:"28px 0 24px" }}>
              <div style={{ fontSize:52, animation:"breathe 5s ease-in-out infinite", marginBottom:12 }}>✦</div>
              <div style={{ fontFamily:"'Cinzel', serif", fontSize:10, letterSpacing:4, color:D.textFaint, minHeight:16, marginBottom:8 }}>{typed}<span style={{ opacity:0.3 }}>|</span></div>
              <p style={{ fontFamily:"'Crimson Pro', serif", fontSize:15, color:D.textMuted, fontStyle:"italic", lineHeight:1.8 }}>Ten AI tools. Orbiting your every need.</p>
            </div>

            <div style={{ display:"grid", gridTemplateColumns:"1fr 1fr", gap:11 }}>
              {TOOLS.map((t, i) => (
                <div key={t.id} className="tool-card" onClick={() => { setActiveTool(t.id); setResponse(""); setInput(""); setScreen("tool"); }}
                  style={{ background:D.card, border:`1px solid ${t.color}20`, borderRadius:13, padding:"16px 15px", animationDelay:`${i*0.05}s`, animation:"fadeUp 0.5s ease both", position:"relative", overflow:"hidden", boxShadow: darkMode ? "none" : "0 2px 12px rgba(0,0,0,0.06)" }}>
                  <div style={{ position:"absolute", top:-12, right:-12, width:60, height:60, borderRadius:"50%", background:t.color, opacity:darkMode?0.06:0.07, filter:"blur(14px)" }} />
                  <div style={{ fontSize:24, marginBottom:7 }}>{t.icon}</div>
                  <div style={{ fontFamily:"'Cinzel', serif", fontSize:10, fontWeight:600, letterSpacing:2, color:t.color, marginBottom:4 }}>{t.name.toUpperCase()}</div>
                  <div style={{ fontFamily:"'Crimson Pro', serif", fontSize:12, color:D.textMuted, lineHeight:1.5, fontStyle:"italic" }}>{t.tagline}</div>
                  <div style={{ position:"absolute", bottom:11, right:13, fontSize:13, color:`${t.color}55` }}>→</div>
                </div>
              ))}
            </div>

            <div style={{ textAlign:"center", marginTop:26, paddingTop:18, borderTop:`1px solid ${D.border}` }}>
              <div style={{ fontFamily:"'Crimson Pro', serif", fontSize:11, color:D.textFaint, fontStyle:"italic" }}>Powered by Claude · Real-time AI · ORBITIQ © 2026</div>
            </div>
          </div>
        )}

        {/* TOOL */}
        {screen === "tool" && tool && (
          <div style={{ animation:"fadeUp 0.4s ease" }}>
            <div style={{ padding:"22px 0 18px", display:"flex", alignItems:"center", gap:13 }}>
              <button onClick={() => { setActiveTool(null); setResponse(""); setInput(""); setScreen("home"); }}
                style={{ background:"none", border:`1px solid ${D.border}`, borderRadius:8, color:D.textMuted, cursor:"pointer", width:34, height:34, fontSize:15, fontFamily:"inherit", flexShrink:0 }}>←</button>
              <div>
                <div style={{ fontFamily:"'Cinzel', serif", fontSize:17, fontWeight:600, letterSpacing:3, color:tool.color }}>{tool.icon} {tool.name.toUpperCase()}</div>
                <div style={{ fontFamily:"'Crimson Pro', serif", fontStyle:"italic", color:D.textMuted, fontSize:13, marginTop:1 }}>{tool.tagline}</div>
              </div>
            </div>

            <div style={{ background:D.bg2, border:`1px solid ${tool.color}33`, borderRadius:13, overflow:"hidden", boxShadow:`0 0 40px ${tool.glow.replace("0.4","0.06")}`, marginBottom:13 }}>
              <textarea value={input} onChange={e => setInput(e.target.value)} placeholder={tool.placeholder}
                onKeyDown={e => e.key==="Enter" && e.metaKey && runTool(tool)}
                style={{ width:"100%", minHeight:95, padding:"15px 17px", background:D.inputBg, border:"none", resize:"none", color:D.text, fontFamily:"'Crimson Pro', serif", fontSize:14, lineHeight:1.7 }} />
              <div style={{ display:"flex", alignItems:"center", justifyContent:"space-between", padding:"9px 15px", borderTop:`1px solid ${tool.color}15`, background:`${tool.color}05` }}>
                <span style={{ fontSize:8, color:D.textFaint, letterSpacing:2, fontFamily:"'Cinzel', serif" }}>CMD + ENTER TO RUN</span>
                <button className="glow-btn" onClick={() => runTool(tool)} disabled={loading || !input.trim()}
                  style={{ background: loading||!input.trim() ? D.bg3 : tool.color, border:"none", borderRadius:10, padding:"9px 24px", color: loading||!input.trim() ? D.textFaint : "#030508", cursor: loading||!input.trim() ? "not-allowed":"pointer", fontFamily:"'Cinzel', serif", fontSize:10, fontWeight:700, letterSpacing:3, boxShadow: !loading&&input.trim()?`0 0 20px ${tool.glow}`:"none", transition:"all 0.3s" }}>
                  {loading ? "THINKING…" : "ACTIVATE"}
                </button>
              </div>
            </div>

            <div style={{ marginBottom:16 }}>
              <div style={{ fontSize:8, color:D.textFaint, letterSpacing:3, fontFamily:"'Cinzel', serif", marginBottom:6 }}>QUICK START</div>
              <div style={{ display:"flex", gap:7, flexWrap:"wrap" }}>
                {tool.examples.map((ex, i) => (
                  <div key={i} className="example-chip" onClick={() => { setInput(ex); runTool(tool, ex); }}
                    style={{ padding:"5px 12px", borderRadius:20, border:`1px solid ${tool.color}33`, color:D.textMuted, fontSize:11, opacity:0.65, fontFamily:"'Crimson Pro', serif", fontStyle:"italic", transition:"all 0.2s" }}>
                    {ex}
                  </div>
                ))}
              </div>
            </div>

            {loading && (
              <div style={{ background:D.bg2, border:`1px solid ${tool.color}22`, borderRadius:13, padding:"26px 20px", textAlign:"center" }}>
                <div style={{ width:42, height:42, borderRadius:"50%", border:`2px solid ${tool.color}22`, borderTopColor:tool.color, animation:"spin-slow 1s linear infinite", margin:"0 auto 13px" }} />
                <div style={{ fontFamily:"'Cinzel', serif", fontSize:10, letterSpacing:3, color:tool.color }}>INTELLIGENCE PROCESSING</div>
                <div style={{ fontFamily:"'Crimson Pro', serif", fontStyle:"italic", color:D.textFaint, marginTop:6, fontSize:12 }}>Crafting your personalized response…</div>
                {[100,83,91,70,87].map((w,i) => (
                  <div key={i} style={{ height:7, borderRadius:4, marginTop:9, width:`${w}%`, background:`linear-gradient(90deg,${D.bg3} 0%,${tool.color}25 50%,${D.bg3} 100%)`, backgroundSize:"200% 100%", animation:`shimmer 1.5s ease-in-out infinite`, animationDelay:`${i*0.12}s` }} />
                ))}
              </div>
            )}

            {response && !loading && (
              <div ref={outputRef} style={{ background:D.bg2, border:`1px solid ${tool.color}33`, borderRadius:13, padding:"20px", animation:"fadeUp 0.5s ease", boxShadow:`0 0 50px ${tool.glow.replace("0.4","0.05")}`, position:"relative", overflow:"hidden" }}>
                <div style={{ position:"absolute", top:0, left:"8%", right:"8%", height:1, background:`linear-gradient(90deg,transparent,${tool.color},transparent)` }} />
                <div style={{ display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:13 }}>
                  <div style={{ fontFamily:"'Cinzel', serif", fontSize:9, letterSpacing:3, color:tool.color }}>✦ ORBITIQ RESPONSE</div>
                  <div style={{ display:"flex", gap:6 }}>
                    <button onClick={copyResponse} style={{ background:D.bg3, border:`1px solid ${D.border}`, borderRadius:6, padding:"4px 10px", color:copied?"#34d399":D.textMuted, cursor:"pointer", fontSize:8, letterSpacing:1, fontFamily:"'Cinzel', serif", transition:"color 0.3s" }}>{copied ? "✓ COPIED" : "COPY"}</button>
                    <button onClick={exportPDF} disabled={pdfLoading} style={{ background:`${tool.color}15`, border:`1px solid ${tool.color}44`, borderRadius:6, padding:"4px 10px", color:tool.color, cursor:pdfLoading?"not-allowed":"pointer", fontSize:8, letterSpacing:1, fontFamily:"'Cinzel', serif" }}>{pdfLoading ? "…" : "⬇ PDF"}</button>
                  </div>
                </div>
                <div style={{ fontFamily:"'Crimson Pro', serif", fontSize:14, lineHeight:1.9, color:D.text, whiteSpace:"pre-wrap" }}>
                  {response.split(/(\*\*.*?\*\*)/g).map((part, i) =>
                    part.startsWith("**") && part.endsWith("**")
                      ? <strong key={i} style={{ color:tool.color, fontWeight:600 }}>{part.slice(2,-2)}</strong>
                      : <span key={i}>{part}</span>
                  )}
                </div>
                <div style={{ marginTop:16, paddingTop:13, borderTop:`1px solid ${D.border}`, display:"flex", gap:7, flexWrap:"wrap" }}>
                  <button onClick={() => { setInput(""); setResponse(""); }} style={{ background:"none", border:`1px solid ${tool.color}33`, borderRadius:8, padding:"7px 16px", color:tool.color, cursor:"pointer", fontSize:9, letterSpacing:2, fontFamily:"'Cinzel', serif" }}>NEW QUERY</button>
                  <button onClick={() => runTool(tool)} style={{ background:`${tool.color}15`, border:`1px solid ${tool.color}44`, borderRadius:8, padding:"7px 16px", color:tool.color, cursor:"pointer", fontSize:9, letterSpacing:2, fontFamily:"'Cinzel', serif" }}>REGENERATE</button>
                </div>
              </div>
            )}

            <div style={{ marginTop:22 }}>
              <div style={{ fontSize:8, color:D.textFaint, letterSpacing:3, fontFamily:"'Cinzel', serif", marginBottom:9 }}>OTHER TOOLS</div>
              <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
                {TOOLS.filter(t => t.id !== activeTool).map(t => (
                  <div key={t.id} className="nav-pill" onClick={() => { setActiveTool(t.id); setResponse(""); setInput(""); }}
                    style={{ padding:"5px 11px", borderRadius:20, border:`1px solid ${t.color}30`, color:t.color, fontSize:10, cursor:"pointer", fontFamily:"'Cinzel', serif", letterSpacing:1, opacity:0.7, transition:"all 0.2s" }}>
                    {t.icon} {t.name}
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
